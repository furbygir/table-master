
minetest.register_node("table:table_wood", {
    description = "Table",
    drawtype = 'mesh',
    mesh = 'table.obj',
    tiles = {"default_wood.png"},
    groups = {choppy = 1, oddly_breakable_by_hand = 3, wood = 1},
})